from django.urls import path
from samuka_app.views import home

urlpatterns = [
    path(' ', home ),
]
